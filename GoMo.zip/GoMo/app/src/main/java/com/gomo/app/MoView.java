package com.gomo.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.Random;

public class MoView extends View {

    // ---- timing ----
    private static final float DOWN = 45f;   // ms, mallet swing down
    private static final float UP = 320f;    // ms, mallet return
    private static final int[] AUTO_BPM = {0, 40, 60, 90, 120};

    private final MainActivity act;
    private final float dp;
    private final Random rnd = new Random();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final NumberFormat nf = NumberFormat.getInstance(new Locale("vi", "VN"));

    // ---- geometry ----
    private int W, H;
    private float cx, cy, R, rx, ry;
    private float pivX, pivY, malletLen, hitAng, restAng, headR, stickW;
    private float hitX, hitY;
    private float cushY;

    // ---- paints / shaders ----
    private final Paint bgP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint vignP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bodyP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint aoP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint grainP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint specP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint spec2P = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rimP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint goldP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint scaleP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint slitP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint holeP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadowP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint floorP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cushTopP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cushSideP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pipingP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tasselP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stickP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint headP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gripP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint malletShadowP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint flashP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sparkP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dustP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint floatP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint numP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint subP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint barP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint btnFillP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint btnStrokeP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint btnLabelP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint btnValP = new Paint(Paint.ANTI_ALIAS_FLAG);

    private RadialGradient headShader;
    private final Matrix headM = new Matrix();
    private final Path bodyPath = new Path();
    private final Path knobPath = new Path();
    private final Path slitPath = new Path();
    private final Path innerBand = new Path();
    private final ArrayList<Path> grain = new ArrayList<>();
    private final RectF tmp = new RectF();
    private final RectF[] btn = new RectF[5];
    private float slitLX, slitLY, slitRX, slitRY;

    // ---- state ----
    private long lastStrike = -100000;
    private float strikeFrom;
    private long impactTime = -100000;
    private long bellTime = -100000;
    private long numPopTime = -100000;
    private int pressedBtn = -1;
    private long pressedTime = 0;
    private long lastFrame = 0;

    private int count, today, total;
    private String todayKey;
    private boolean soundOn = true, vibOn = true;
    private int musicTrack = 1;          // 0 = tắt, 1 = bài 1, 2 = bài 2
    private int loadedTrack = 0;
    private MediaPlayer music;
    private float musicVol = 0f;
    private int autoIdx = 0;

    private static class Ripple { long birth; boolean big; Ripple(long b, boolean g) { birth = b; big = g; } }
    private static class Spark { float x, y, vx, vy, r; long birth; float life; }
    private static class Floater { float x, y; long birth; String text; boolean big; }
    private static class Dust { float x, y, r, v, ph; }

    private final ArrayList<Ripple> ripples = new ArrayList<>();
    private final ArrayList<Spark> sparks = new ArrayList<>();
    private final ArrayList<Floater> floaters = new ArrayList<>();
    private final Dust[] dust = new Dust[46];

    // ---- audio / haptic ----
    private SoundPool pool;
    private final int[] knockIds = new int[3];
    private int bellId;
    private int lastKnock = -1;
    private final Vibrator vib;
    private final SharedPreferences sp;

    private final Runnable autoRun = new Runnable() {
        @Override public void run() {
            int bpm = AUTO_BPM[autoIdx];
            if (bpm <= 0) return;
            strike();
            handler.postDelayed(this, 60000L / bpm);
        }
    };

    @SuppressWarnings("deprecation")
    public MoView(MainActivity a) {
        super(a);
        act = a;
        dp = a.getResources().getDisplayMetrics().density;
        sp = a.getSharedPreferences("gomo", Context.MODE_PRIVATE);
        count = sp.getInt("count", 0);
        total = sp.getInt("total", 0);
        soundOn = sp.getBoolean("sound", true);
        vibOn = sp.getBoolean("vib", true);
        musicTrack = sp.getInt("musicTrack", 1);
        todayKey = dayKey();
        today = todayKey.equals(sp.getString("dayKey", "")) ? sp.getInt("today", 0) : 0;

        pool = new SoundPool.Builder().setMaxStreams(10)
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .build();
        knockIds[0] = pool.load(a, com.gomo.app.R.raw.mo1, 1);
        knockIds[1] = pool.load(a, com.gomo.app.R.raw.mo2, 1);
        knockIds[2] = pool.load(a, com.gomo.app.R.raw.mo3, 1);
        bellId = pool.load(a, com.gomo.app.R.raw.chuong, 1);
        vib = (Vibrator) a.getSystemService(Context.VIBRATOR_SERVICE);

        for (int i = 0; i < 5; i++) btn[i] = new RectF();
        for (int i = 0; i < dust.length; i++) dust[i] = new Dust();
        setupStaticPaints();
    }

    private void ensureMusic() {
        if (music != null && loadedTrack == musicTrack) return;
        if (music != null) { music.release(); music = null; }
        try {
            int res = musicTrack == 1 ? com.gomo.app.R.raw.nhac2 : com.gomo.app.R.raw.nhac;
            music = MediaPlayer.create(getContext(), res);
            loadedTrack = musicTrack;
            if (music != null) {
                music.setLooping(true);
                music.setVolume(0f, 0f);
            }
        } catch (Exception ignored) { music = null; }
    }

    void startMusic() {
        if (musicTrack == 0) return;
        ensureMusic();
        if (music != null && !music.isPlaying()) { musicVol = 0f; music.setVolume(0f, 0f); music.start(); }
    }

    private void stopMusic() {
        if (music != null && music.isPlaying()) music.pause();
    }

    private void updateMusicFade(float dt) {
        if (music == null || !music.isPlaying()) return;
        float target = 0.42f;
        if (musicVol < target) {
            musicVol = Math.min(target, musicVol + dt * 0.15f);   // ~3 s fade in
            music.setVolume(musicVol, musicVol);
        }
    }

    private float sp(float v) { return v * getResources().getDisplayMetrics().scaledDensity; }

    private static String dayKey() { return new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date()); }

    private void setupStaticPaints() {
        Typeface serifBold = Typeface.create(Typeface.SERIF, Typeface.BOLD);
        Typeface sans = Typeface.create("sans-serif-medium", Typeface.NORMAL);

        grainP.setStyle(Paint.Style.STROKE);
        rimP.setStyle(Paint.Style.STROKE);
        goldP.setStyle(Paint.Style.STROKE);
        scaleP.setStyle(Paint.Style.STROKE);
        scaleP.setColor(0xFFE2B45A);
        slitP.setStyle(Paint.Style.STROKE);
        slitP.setStrokeCap(Paint.Cap.ROUND);
        pipingP.setStyle(Paint.Style.STROKE);
        tasselP.setStrokeCap(Paint.Cap.ROUND);
        ringP.setStyle(Paint.Style.STROKE);
        malletShadowP.setColor(0xFF000000);
        malletShadowP.setStrokeCap(Paint.Cap.ROUND);

        labelP.setColor(0xFFD9B46A);
        labelP.setTextAlign(Paint.Align.CENTER);
        labelP.setTextSize(sp(13));
        labelP.setLetterSpacing(0.35f);
        labelP.setTypeface(sans);

        numP.setColor(0xFFFFE6B0);
        numP.setTextAlign(Paint.Align.CENTER);
        numP.setTextSize(sp(76));
        numP.setTypeface(serifBold);
        numP.setShadowLayer(22 * dp, 0, 0, 0xAAFF9A3C);

        subP.setColor(0xC0E8D2B0);
        subP.setTextAlign(Paint.Align.CENTER);
        subP.setTextSize(sp(14));
        subP.setTypeface(sans);

        floatP.setTextAlign(Paint.Align.CENTER);
        floatP.setTypeface(serifBold);

        btnFillP.setStyle(Paint.Style.FILL);
        btnStrokeP.setStyle(Paint.Style.STROKE);
        btnStrokeP.setStrokeWidth(1.2f * dp);
        btnLabelP.setTextAlign(Paint.Align.CENTER);
        btnLabelP.setTextSize(sp(10));
        btnLabelP.setLetterSpacing(0.08f);
        btnLabelP.setColor(0xFFD9B46A);
        btnLabelP.setTypeface(sans);
        btnValP.setTextAlign(Paint.Align.CENTER);
        btnValP.setTextSize(sp(15));
        btnValP.setColor(0xFFFFEBC8);
        btnValP.setTypeface(serifBold);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        W = w; H = h;
        cx = w / 2f;
        cy = h * 0.53f;
        R = Math.min(w * 0.28f, h * 0.19f);
        rx = R * 1.05f;
        ry = R * 0.9f;
        cushY = cy + ry * 0.84f;
        Shader.TileMode CL = Shader.TileMode.CLAMP;

        bgP.setShader(new LinearGradient(0, 0, 0, h,
                new int[]{0xFF2E0F07, 0xFF1C0704, 0xFF0A0302}, new float[]{0f, 0.55f, 1f}, CL));
        glowP.setShader(new RadialGradient(cx, cy - R * 0.1f, R * 2.7f,
                new int[]{0x88FFA04A, 0x30FF7A20, 0x00000000}, new float[]{0f, 0.45f, 1f}, CL));
        vignP.setShader(new RadialGradient(cx, h * 0.5f, Math.max(w, h) * 0.78f,
                new int[]{0x00000000, 0x00000000, 0xC0000000}, new float[]{0f, 0.5f, 1f}, CL));

        // --- body ---
        bodyPath.reset();
        bodyPath.addOval(new RectF(cx - rx, cy - ry, cx + rx, cy + ry), Path.Direction.CW);
        knobPath.reset();
        knobPath.moveTo(cx - 0.44f * rx, cy - 0.74f * ry);
        knobPath.cubicTo(cx - 0.50f * rx, cy - 1.30f * ry, cx + 0.50f * rx, cy - 1.30f * ry, cx + 0.44f * rx, cy - 0.74f * ry);
        knobPath.close();
        innerBand.reset();
        innerBand.addOval(new RectF(cx - rx * 0.86f, cy - ry * 0.86f, cx + rx * 0.86f, cy + ry * 0.86f), Path.Direction.CW);

        bodyP.setShader(new RadialGradient(cx - 0.35f * rx, cy - 0.45f * ry, R * 1.8f,
                new int[]{0xFFF4A574, 0xFFC9562E, 0xFF8E2A12, 0xFF4A1206, 0xFF220703},
                new float[]{0f, 0.2f, 0.5f, 0.8f, 1f}, CL));
        aoP.setShader(new LinearGradient(0, cy - ry * 0.1f, 0, cy + ry,
                0x00000000, 0x8C000000, CL));
        specP.setShader(new RadialGradient(cx - 0.38f * rx, cy - 0.48f * ry, R * 0.45f,
                new int[]{0x99FFF4E0, 0x33FFE0C0, 0x00FFFFFF}, new float[]{0f, 0.45f, 1f}, CL));
        spec2P.setShader(new RadialGradient(cx - 0.47f * rx, cy - 0.56f * ry, R * 0.1f,
                new int[]{0xEEFFFFFF, 0x00FFFFFF}, null, CL));
        rimP.setStrokeWidth(3f * dp);
        rimP.setShader(new LinearGradient(cx - rx, cy - ry, cx + rx, cy + ry,
                new int[]{0x00FFB070, 0x00FFB070, 0xB0FFB070}, new float[]{0f, 0.6f, 1f}, CL));
        goldP.setShader(new LinearGradient(cx - rx, cy - ry, cx + rx, cy + ry,
                new int[]{0xFFFFEAA8, 0xFFD4A030, 0xFF8A5A10, 0xFFE8C060}, null, CL));

        // wood grain (end-grain rings, slightly wobbly)
        grain.clear();
        float gx = cx + 0.25f * rx, gy = cy + 0.35f * ry;
        Random gr = new Random(11);
        for (int i = 1; i <= 18; i++) {
            float k = i / 18f * 1.35f;
            Path p = new Path();
            int N = 96;
            double ph = gr.nextDouble() * 6.28;
            for (int j = 0; j <= N; j++) {
                double a = j * 2 * Math.PI / N;
                double wob = 1 + 0.04 * Math.sin(a * 3 + ph) + 0.02 * Math.sin(a * 7 + ph * 2);
                float x = (float) (gx + Math.cos(a) * rx * k * wob * 1.1);
                float y = (float) (gy + Math.sin(a) * ry * k * wob * 0.78);
                if (j == 0) p.moveTo(x, y); else p.lineTo(x, y);
            }
            p.close();
            grain.add(p);
        }

        // mouth slit
        slitLX = cx - 0.62f * rx; slitLY = cy + 0.18f * ry;
        slitRX = cx + 0.62f * rx; slitRY = cy + 0.18f * ry;
        slitPath.reset();
        slitPath.moveTo(slitLX, slitLY);
        slitPath.quadTo(cx, cy + 0.46f * ry, slitRX, slitRY);
        slitP.setStrokeWidth(R * 0.075f);

        // floor & cushion
        floorP.setShader(new RadialGradient(cx, cushY + ry * 0.3f, rx * 1.8f,
                new int[]{0xAA000000, 0x00000000}, null, CL));
        cushTopP.setShader(new RadialGradient(cx - 0.3f * rx, cushY - 0.12f * ry, rx * 1.5f,
                new int[]{0xFFDC4636, 0xFFA11E18, 0xFF5A0A0A}, new float[]{0f, 0.45f, 1f}, CL));
        cushSideP.setShader(new LinearGradient(0, cushY, 0, cushY + ry * 0.45f,
                0xFF6A0E0C, 0xFF240302, CL));
        pipingP.setStrokeWidth(2.2f * dp);
        pipingP.setShader(goldP.getShader());
        tasselP.setColor(0xFFD9A440);
        shadowP.setShader(new RadialGradient(cx, cy + ry * 0.94f, rx * 0.9f,
                new int[]{0xCC000000, 0x00000000}, null, CL));

        // mallet geometry
        headR = R * 0.19f;
        stickW = R * 0.075f;
        double phi = Math.toRadians(-55);
        float px = (float) (cx + rx * Math.cos(phi));
        float py = (float) (cy + ry * Math.sin(phi));
        float nx = (px - cx) / (rx * rx), ny = (py - cy) / (ry * ry);
        float nl = (float) Math.hypot(nx, ny);
        nx /= nl; ny /= nl;
        hitX = px; hitY = py;
        float hx = px + nx * headR * 0.95f, hy = py + ny * headR * 0.95f;
        pivX = cx + R * 1.75f;
        pivY = cy - R * 0.05f;
        malletLen = (float) Math.hypot(hx - pivX, hy - pivY);
        hitAng = (float) Math.atan2(hy - pivY, hx - pivX);
        restAng = hitAng + (float) Math.toRadians(37);
        headShader = new RadialGradient(-0.35f * headR, -0.4f * headR, headR * 1.45f,
                new int[]{0xFFF8E8C8, 0xFFCDAB7E, 0xFF6B4A2A, 0xFF2A1A0C},
                new float[]{0f, 0.35f, 0.75f, 1f}, CL);
        headP.setShader(headShader);
        stickP.setShader(new LinearGradient(0, -stickW / 2, 0, stickW / 2,
                new int[]{0xFF3A1E0C, 0xFFC08A55, 0xFF6A3E1E, 0xFF2A1408},
                new float[]{0f, 0.32f, 0.7f, 1f}, CL));

        // dust
        for (Dust d : dust) {
            d.x = rnd.nextFloat() * w;
            d.y = rnd.nextFloat() * h;
            d.r = (0.6f + rnd.nextFloat() * 1.8f) * dp;
            d.v = (6 + rnd.nextFloat() * 18) * dp;
            d.ph = rnd.nextFloat() * 6.28f;
        }

        // buttons
        float margin = 12 * dp, gap = 7 * dp, bh = 58 * dp;
        float bw = (w - 2 * margin - 4 * gap) / 5f;
        float top = h - 30 * dp - bh;
        for (int i = 0; i < 5; i++) {
            float l = margin + i * (bw + gap);
            btn[i].set(l, top, l + bw, top + bh);
        }
    }

    // ================= interaction =================

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) {
            int idx = e.getActionIndex();
            float x = e.getX(idx), y = e.getY(idx);
            for (int i = 0; i < 5; i++) {
                tmp.set(btn[i]);
                tmp.inset(-4 * dp, -8 * dp);
                if (tmp.contains(x, y)) {
                    pressedBtn = i;
                    pressedTime = SystemClock.uptimeMillis();
                    onButton(i);
                    return true;
                }
            }
            strike();
            return true;
        }
        return true;
    }

    private void onButton(int i) {
        tick(12);
        switch (i) {
            case 0:
                autoIdx = (autoIdx + 1) % AUTO_BPM.length;
                handler.removeCallbacks(autoRun);
                if (AUTO_BPM[autoIdx] > 0) handler.postDelayed(autoRun, 250);
                break;
            case 1:
                soundOn = !soundOn;
                sp.edit().putBoolean("sound", soundOn).apply();
                break;
            case 2:
                musicTrack = (musicTrack + 1) % 3;
                sp.edit().putInt("musicTrack", musicTrack).apply();
                stopMusic();
                startMusic();
                break;
            case 3:
                vibOn = !vibOn;
                sp.edit().putBoolean("vib", vibOn).apply();
                if (vibOn) tick(30);
                break;
            case 4:
                act.confirmReset();
                break;
        }
    }

    void resetCount() {
        count = 0;
        sp.edit().putInt("count", 0).apply();
        numPopTime = SystemClock.uptimeMillis();
    }

    void onPauseApp() {
        autoIdx = 0;
        handler.removeCallbacks(autoRun);
        stopMusic();
        save();
    }

    void release() {
        handler.removeCallbacks(autoRun);
        if (pool != null) { pool.release(); pool = null; }
        if (music != null) { music.release(); music = null; }
    }

    private void save() {
        sp.edit().putInt("count", count).putInt("total", total)
                .putInt("today", today).putString("dayKey", todayKey).apply();
    }

    private void tick(int ms) {
        if (!vibOn || vib == null || !vib.hasVibrator()) return;
        try {
            int amp = vib.hasAmplitudeControl() ? Math.min(255, 60 + ms * 6) : VibrationEffect.DEFAULT_AMPLITUDE;
            vib.vibrate(VibrationEffect.createOneShot(ms, amp));
        } catch (Exception ignored) { }
    }

    private void strike() {
        long now = SystemClock.uptimeMillis();
        strikeFrom = malletAngle(now);
        lastStrike = now;
        long imp = now + (long) DOWN;
        impactTime = imp;
        numPopTime = imp;

        String k = dayKey();
        if (!k.equals(todayKey)) { todayKey = k; today = 0; }
        count++; today++; total++;
        save();
        boolean milestone = count % 108 == 0;

        if (soundOn && pool != null) {
            int v;
            do { v = rnd.nextInt(3); } while (v == lastKnock);
            lastKnock = v;
            float rate = 0.96f + rnd.nextFloat() * 0.08f;
            float vol = 0.88f + rnd.nextFloat() * 0.12f;
            pool.play(knockIds[v], vol, vol, 1, 0, rate);
            if (milestone) pool.play(bellId, 1f, 1f, 2, 0, 1f);
        }
        if (milestone) {
            bellTime = imp;
            if (vibOn && vib != null && vib.hasVibrator()) {
                try { vib.vibrate(VibrationEffect.createWaveform(new long[]{0, 40, 70, 40, 70, 90}, -1)); } catch (Exception ignored) { }
            }
        } else {
            tick(22);
        }

        ripples.add(new Ripple(imp, milestone));
        int n = milestone ? 40 : 14;
        for (int i = 0; i < n; i++) {
            Spark s = new Spark();
            s.x = hitX; s.y = hitY;
            double ang = Math.toRadians(-90 + (rnd.nextFloat() - 0.3f) * (milestone ? 300 : 140));
            float spd = (milestone ? 260 : 160) * dp * (0.4f + rnd.nextFloat());
            s.vx = (float) Math.cos(ang) * spd;
            s.vy = (float) Math.sin(ang) * spd;
            s.r = (1.2f + rnd.nextFloat() * 2.2f) * dp;
            s.birth = imp;
            s.life = 0.5f + rnd.nextFloat() * 0.5f;
            sparks.add(s);
        }
        Floater f = new Floater();
        f.birth = imp;
        f.x = cx + (rnd.nextFloat() - 0.5f) * R * 0.9f;
        f.y = cy - ry * 1.3f;
        f.big = milestone;
        f.text = milestone ? "Tròn " + nf.format(count) + " lần" : "Công đức +1";
        floaters.add(f);
        if (floaters.size() > 24) floaters.remove(0);
        invalidate();
    }

    private float malletAngle(long now) {
        float t = now - lastStrike;
        float sway = (float) (0.025 * Math.sin(now / 650.0));
        if (t < DOWN) {
            float p = t / DOWN;
            p = p * p;
            return strikeFrom + (hitAng - strikeFrom) * p;
        }
        float u = (t - DOWN) / UP;
        if (u >= 1f) return restAng + sway;
        float e = 1 - (float) Math.pow(1 - u, 3);
        return hitAng + (restAng + sway - hitAng) * e;
    }

    // ================= drawing =================

    @Override
    protected void onDraw(Canvas c) {
        long now = SystemClock.uptimeMillis();
        float dt = lastFrame == 0 ? 0.016f : Math.min(0.05f, (now - lastFrame) / 1000f);
        lastFrame = now;
        updateMusicFade(dt);
        float tImp = (now - impactTime) / 1000f;
        boolean hit = now >= impactTime;
        float tBell = (now - bellTime) / 1000f;
        boolean bell = now >= bellTime && tBell < 4f;

        // background
        c.drawRect(0, 0, W, H, bgP);
        float glowA = 0.75f + 0.08f * (float) Math.sin(now / 900.0)
                + (hit ? 0.5f * (float) Math.exp(-tImp * 3.5) : 0)
                + (bell ? 0.9f * (float) Math.exp(-tBell * 0.9) : 0);
        glowP.setAlpha((int) (255 * Math.min(1f, glowA)));
        c.save();
        float gs = 1f + (bell ? 0.5f * (float) Math.exp(-tBell * 0.9) : 0);
        c.scale(gs, gs, cx, cy);
        c.drawCircle(cx, cy - R * 0.1f, R * 2.7f, glowP);
        c.restore();
        drawDust(c, now, dt);

        // floor shadow + cushion
        tmp.set(cx - rx * 1.8f, cushY - ry * 0.1f, cx + rx * 1.8f, cushY + ry * 0.75f);
        c.drawOval(tmp, floorP);
        drawCushion(c);

        // ground ripples (sound waves)
        drawRipples(c, now);

        // squash & wobble of the mõ
        float s = 0;
        if (hit && tImp < 1.5f) s = (float) (Math.exp(-tImp * 9) * Math.cos(tImp * 2 * Math.PI * 7));
        float breathe = (float) Math.sin(now / 1400.0) * 0.004f;
        c.save();
        c.rotate(1.6f * s, cx, cy + ry);
        c.scale(1 + 0.03f * s + breathe, 1 - 0.05f * s - breathe, cx, cy + ry);
        drawMo(c, hit ? (float) Math.exp(-tImp * 12) : 0f, bell ? (float) Math.exp(-tBell * 1.5) : 0f);
        c.restore();

        drawMallet(c, now);
        drawSparks(c, now);
        drawFloaters(c, now);

        c.drawRect(0, 0, W, H, vignP);
        drawCounter(c, now);
        drawButtons(c, now);

        postInvalidateOnAnimation();
    }

    private void drawDust(Canvas c, long now, float dt) {
        for (Dust d : dust) {
            d.y -= d.v * dt;
            d.x += (float) Math.sin(now / 1800.0 + d.ph) * 4 * dp * dt;
            if (d.y < -10) { d.y = H + 10; d.x = rnd.nextFloat() * W; }
            float tw = 0.5f + 0.5f * (float) Math.sin(now / 500.0 + d.ph * 3);
            float distGlow = 1f - Math.min(1f, (float) Math.hypot(d.x - cx, d.y - cy) / (R * 3.2f));
            int al = (int) (40 + 150 * tw * (0.25f + distGlow));
            dustP.setColor((Math.min(255, al) << 24) | 0xFFD49A);
            c.drawCircle(d.x, d.y, d.r, dustP);
        }
    }

    private void drawCushion(Canvas c) {
        float w = rx * 1.32f, th = ry * 0.30f, side = ry * 0.22f;
        // side
        tmp.set(cx - w, cushY - th + side, cx + w, cushY + th + side);
        c.drawOval(tmp, cushSideP);
        c.drawRect(cx - w, cushY, cx + w, cushY + side, cushSideP);
        // top
        tmp.set(cx - w, cushY - th, cx + w, cushY + th);
        c.drawOval(tmp, cushTopP);
        c.drawOval(tmp, pipingP);
        // lower piping
        tmp.set(cx - w, cushY - th + side, cx + w, cushY + th + side);
        c.drawArc(tmp, 0, 180, false, pipingP);
        // tassels
        for (int sgn = -1; sgn <= 1; sgn += 2) {
            float tx = cx + sgn * w * 0.98f, ty = cushY + side * 0.6f;
            tasselP.setStrokeWidth(1.6f * dp);
            for (int k = -3; k <= 3; k++) {
                tasselP.setAlpha(200 - Math.abs(k) * 20);
                c.drawLine(tx, ty + 6 * dp, tx + k * 1.6f * dp, ty + ry * 0.38f, tasselP);
            }
            tasselP.setAlpha(255);
            c.drawCircle(tx, ty + 4 * dp, 5 * dp, tasselP);
            tasselP.setStrokeWidth(4 * dp);
            c.drawLine(tx - 4 * dp, ty + 12 * dp, tx + 4 * dp, ty + 12 * dp, tasselP);
        }
        // contact shadow
        tmp.set(cx - rx * 0.9f, cy + ry * 0.8f, cx + rx * 0.9f, cy + ry * 1.08f);
        c.drawOval(tmp, shadowP);
    }

    private void drawRipples(Canvas c, long now) {
        Iterator<Ripple> it = ripples.iterator();
        while (it.hasNext()) {
            Ripple r = it.next();
            if (now < r.birth) continue;
            float dur = r.big ? 2.2f : 1.2f;
            float p = (now - r.birth) / 1000f / dur;
            if (p >= 1) { it.remove(); continue; }
            for (int k = 0; k < (r.big ? 3 : 1); k++) {
                float pp = p - k * 0.12f;
                if (pp <= 0) continue;
                float rr = rx * (1.1f + (r.big ? 2.4f : 1.6f) * pp);
                int al = (int) (Math.pow(1 - pp, 2) * (r.big ? 220 : 150));
                ringP.setColor((al << 24) | 0xFFC86A);
                ringP.setStrokeWidth((2.4f * (1 - pp) + 0.6f) * dp);
                tmp.set(cx - rr, cushY - rr * 0.28f, cx + rr, cushY + rr * 0.28f);
                c.drawOval(tmp, ringP);
            }
        }
    }

    private void drawMo(Canvas c, float flash, float bellGlow) {
        // knob / handle on top
        c.drawPath(knobPath, bodyP);
        c.save();
        c.clipPath(knobPath);
        c.drawPath(knobPath, aoP);
        c.restore();
        c.drawPath(knobPath, goldP);
        goldP.setStrokeWidth(1.6f * dp);
        tmp.set(cx - 0.17f * rx, cy - 1.10f * ry, cx + 0.17f * rx, cy - 0.94f * ry);
        holeP.setShader(null);
        holeP.setColor(0xFF140402);
        c.drawOval(tmp, holeP);
        c.drawOval(tmp, goldP);

        // body
        c.drawPath(bodyPath, bodyP);
        c.save();
        c.clipPath(bodyPath);
        for (int i = 0; i < grain.size(); i++) {
            grainP.setStrokeWidth((i % 3 == 0 ? 1.6f : 1.0f) * dp);
            grainP.setColor(i % 2 == 0 ? 0x2A000000 : 0x14FFC090);
            c.drawPath(grain.get(i), grainP);
        }
        // fish-scale carving (upper part)
        c.save();
        c.clipPath(innerBand);
        c.clipRect(cx - rx, cy - ry, cx + rx, cy + 0.02f * ry);
        float sr = R * 0.075f;
        scaleP.setStrokeWidth(1.1f * dp);
        scaleP.setAlpha(55);
        int row = 0;
        for (float y = cy - 0.75f * ry; y < cy + 0.05f * ry; y += sr * 1.15f, row++) {
            float off = (row % 2) * sr;
            for (float x = cx - rx - off; x < cx + rx; x += sr * 2) {
                tmp.set(x, y - sr, x + 2 * sr, y + sr);
                c.drawArc(tmp, 0, 180, false, scaleP);
            }
        }
        c.restore();
        c.drawPath(bodyPath, aoP);
        c.drawPath(bodyPath, specP);
        c.drawPath(bodyPath, spec2P);
        c.restore();

        // gold band
        goldP.setStrokeWidth(2.4f * dp);
        c.drawPath(innerBand, goldP);
        c.drawPath(bodyPath, rimP);

        // slit (mouth): lit lower lip, dark groove, deep core
        c.save();
        c.translate(0, R * 0.022f);
        slitP.setShader(null);
        slitP.setColor(0x55FFC48A);
        c.drawPath(slitPath, slitP);
        c.restore();
        slitP.setColor(0xFF1E0602);
        c.drawPath(slitPath, slitP);
        float sw = slitP.getStrokeWidth();
        slitP.setStrokeWidth(sw * 0.45f);
        slitP.setColor(0xFF000000);
        c.drawPath(slitPath, slitP);
        slitP.setStrokeWidth(sw);

        drawHole(c, slitLX, slitLY);
        drawHole(c, slitRX, slitRY);

        // impact flash
        if (flash > 0.01f) {
            flashP.setShader(new RadialGradient(hitX, hitY, R * 0.6f,
                    new int[]{((int) (180 * flash) << 24) | 0xFFF0C8, 0x00FFE0A0}, null, Shader.TileMode.CLAMP));
            c.save();
            c.clipPath(bodyPath);
            c.drawCircle(hitX, hitY, R * 0.6f, flashP);
            c.restore();
        }
        if (bellGlow > 0.01f) {
            ringP.setColor(((int) (200 * bellGlow) << 24) | 0xFFD47A);
            ringP.setStrokeWidth(4 * dp * bellGlow + 1);
            c.drawPath(bodyPath, ringP);
        }
    }

    private void drawHole(Canvas c, float x, float y) {
        float r = R * 0.105f;
        // lit lip
        holeP.setShader(null);
        holeP.setColor(0x66FFC48A);
        c.drawCircle(x, y + r * 0.22f, r, holeP);
        holeP.setShader(new RadialGradient(x, y - r * 0.2f, r * 1.1f,
                new int[]{0xFF000000, 0xFF0A0201, 0xFF3A0E05}, new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, r, holeP);
        holeP.setShader(null);
    }

    private void drawMallet(Canvas c, long now) {
        float ang = malletAngle(now);
        float deg = (float) Math.toDegrees(ang);
        float L = malletLen;
        float tail = R * 1.4f;

        // shadow
        c.save();
        c.translate(R * 0.07f, R * 0.11f);
        c.rotate(deg, pivX, pivY);
        malletShadowP.setAlpha(70);
        malletShadowP.setStrokeWidth(stickW);
        c.drawLine(pivX - tail, pivY, pivX + L - headR * 0.5f, pivY, malletShadowP);
        c.drawCircle(pivX + L, pivY, headR, malletShadowP);
        c.restore();

        // stick
        c.save();
        c.rotate(deg, pivX, pivY);
        c.translate(pivX, pivY);
        tmp.set(-tail, -stickW / 2, L - headR * 0.5f, stickW / 2);
        c.drawRoundRect(tmp, stickW / 2, stickW / 2, stickP);
        // red cloth grip with gold stripes
        gripP.setColor(0xFF8E1712);
        tmp.set(-R * 0.75f, -stickW * 0.62f, -R * 0.15f, stickW * 0.62f);
        c.drawRoundRect(tmp, stickW * 0.3f, stickW * 0.3f, gripP);
        gripP.setColor(0x55FFFFFF);
        tmp.set(-R * 0.75f, -stickW * 0.5f, -R * 0.15f, -stickW * 0.25f);
        c.drawRect(tmp, gripP);
        gripP.setColor(0xFFD9A440);
        for (float x = -R * 0.72f; x < -R * 0.16f; x += R * 0.12f) {
            c.drawRect(x, -stickW * 0.62f, x + R * 0.025f, stickW * 0.62f, gripP);
        }
        // collar near head
        gripP.setColor(0xFFB8862E);
        tmp.set(L - headR * 1.35f, -stickW * 0.7f, L - headR * 1.05f, stickW * 0.7f);
        c.drawRoundRect(tmp, stickW * 0.2f, stickW * 0.2f, gripP);
        c.restore();

        // head (lit from top-left in screen space)
        float hx = pivX + L * (float) Math.cos(ang);
        float hy = pivY + L * (float) Math.sin(ang);
        headM.setTranslate(hx, hy);
        headShader.setLocalMatrix(headM);
        c.drawCircle(hx, hy, headR, headP);
    }

    private void drawSparks(Canvas c, long now) {
        float g = 520 * dp;
        Iterator<Spark> it = sparks.iterator();
        while (it.hasNext()) {
            Spark s = it.next();
            if (now < s.birth) continue;
            float t = (now - s.birth) / 1000f;
            if (t > s.life) { it.remove(); continue; }
            float x = s.x + s.vx * t;
            float y = s.y + s.vy * t + 0.5f * g * t * t;
            float k = 1 - t / s.life;
            sparkP.setColor(((int) (255 * k) << 24) | 0xFFD878);
            c.drawCircle(x, y, s.r * (0.5f + 0.5f * k), sparkP);
            sparkP.setColor(((int) (70 * k) << 24) | 0xFFB040);
            c.drawCircle(x, y, s.r * 3f * k, sparkP);
        }
    }

    private void drawFloaters(Canvas c, long now) {
        Iterator<Floater> it = floaters.iterator();
        while (it.hasNext()) {
            Floater f = it.next();
            if (now < f.birth) continue;
            float dur = f.big ? 2.6f : 1.4f;
            float p = (now - f.birth) / 1000f / dur;
            if (p >= 1) { it.remove(); continue; }
            float y = f.y - R * (f.big ? 0.7f : 0.9f) * (1 - (float) Math.pow(1 - p, 2));
            float pop = p < 0.12f ? 0.6f + 0.4f * (p / 0.12f) + 0.15f * (float) Math.sin(p / 0.12f * Math.PI) : 1f;
            float alpha = p < 0.7f ? 1f : 1 - (p - 0.7f) / 0.3f;
            floatP.setTextSize(sp(f.big ? 30 : 17) * pop);
            floatP.setColor(((int) (255 * alpha) << 24) | (f.big ? 0xFFE08A : 0xF5D08A));
            floatP.setShadowLayer(10 * dp, 0, 0, ((int) (200 * alpha) << 24) | 0xFF8A20);
            c.drawText(f.text, f.big ? cx : f.x, y, floatP);
        }
    }

    private void drawCounter(Canvas c, long now) {
        float top = H * 0.085f;
        c.drawText("CÔNG ĐỨC", cx, top, labelP);
        float pt = (now - numPopTime) / 1000f;
        float pop = (now >= numPopTime && pt < 0.6f) ? 1 + 0.09f * (float) Math.exp(-pt * 12) * (float) Math.cos(pt * 30) : 1f;
        float base = top + 84 * dp;
        c.save();
        c.scale(pop, pop, cx, base - 28 * dp);
        c.drawText(nf.format(count), cx, base, numP);
        c.restore();
        c.drawText("Hôm nay " + nf.format(today) + "   ·   Tổng " + nf.format(total), cx, base + 30 * dp, subP);

        // 108 progress
        float bw = W * 0.46f, by = base + 52 * dp, bh = 3.5f * dp;
        int inRound = count % 108;
        float frac = inRound / 108f;
        barP.setShader(null);
        barP.setColor(0x33FFD27A);
        tmp.set(cx - bw / 2, by, cx + bw / 2, by + bh);
        c.drawRoundRect(tmp, bh, bh, barP);
        if (frac > 0) {
            barP.setShader(new LinearGradient(cx - bw / 2, 0, cx + bw / 2, 0, 0xFFB8862E, 0xFFFFE08A, Shader.TileMode.CLAMP));
            tmp.set(cx - bw / 2, by, cx - bw / 2 + bw * frac, by + bh);
            c.drawRoundRect(tmp, bh, bh, barP);
            barP.setShader(null);
        }
        subP.setTextSize(sp(11));
        c.drawText("Chuỗi 108  ·  " + inRound + " / 108", cx, by + 20 * dp, subP);
        subP.setTextSize(sp(14));
    }

    private void drawButtons(Canvas c, long now) {
        String[] lab = {"TỰ GÕ", "TIẾNG", "NHẠC", "RUNG", "ĐẶT LẠI"};
        int bpm = AUTO_BPM[autoIdx];
        String[] val = {
                bpm == 0 ? "Tắt" : bpm + "/ph",
                soundOn ? "Bật" : "Tắt",
                musicTrack == 0 ? "Tắt" : "Bài " + musicTrack,
                vibOn ? "Bật" : "Tắt",
                "Về 0"};
        boolean[] active = {bpm > 0, soundOn, musicTrack > 0, vibOn, false};
        float r = 16 * dp;
        for (int i = 0; i < 5; i++) {
            RectF b = btn[i];
            float press = (i == pressedBtn) ? Math.max(0, 1 - (now - pressedTime) / 250f) : 0;
            c.save();
            float sc = 1 - 0.06f * press;
            c.scale(sc, sc, b.centerX(), b.centerY());
            int fillA = active[i] ? 0x38 : 0x14;
            fillA += (int) (60 * press);
            btnFillP.setColor((fillA << 24) | 0xFFC86A);
            c.drawRoundRect(b, r, r, btnFillP);
            btnStrokeP.setColor(active[i] ? 0xB0E8B860 : 0x55E8B860);
            c.drawRoundRect(b, r, r, btnStrokeP);
            c.drawText(lab[i], b.centerX(), b.top + b.height() * 0.38f, btnLabelP);
            btnValP.setAlpha(active[i] || i == 4 ? 255 : 150);
            c.drawText(val[i], b.centerX(), b.top + b.height() * 0.78f, btnValP);
            c.restore();
        }
    }
}
